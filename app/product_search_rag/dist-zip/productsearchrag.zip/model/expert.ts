export const EXPERTMODEL = {
	"semanticSearchQuestion": "",
	"selectedModel": "GPT-3.5-turbo",
	"ragAnswerPanelIsExpanded": false,
	"ragAnswerListItemIsBusy": false,
	"llmAnswer": "",
	"llmWithRagPrompt": "",
	"movieSemanticSearchAnswerListItemIsExpanded": false,
	"movieSemanticSearchAnswerListItemIsBusy": false,
	"movieSemanticSearchAnswers": []
}
