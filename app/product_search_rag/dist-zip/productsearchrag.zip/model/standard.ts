export const STANDARDMODEL = {
	"withRag": false,
	"ragAnswerPanelIsExpanded": false,
	"ragAnswerListItemIsBusy": false,
	"llmAnswer": "",
	"llmWithRagPrompt": ""
}
